#include "ros/ros.h"
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <boost/asio.hpp>
#include <vector>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/io/io.h>
#include <pcl/filters/passthrough.h>
#include "net_transfor.h"
using boost::asio::ip::tcp;
using namespace std;
enum { max_length = 1024 };
int main(int argc,char**argv)
{
	ros::init(argc,argv,"net_test");
	ros::NodeHandle n;
    /*	
    cout <<sizeof(short)<<endl<<sizeof(int)<<endl;
	  boost::asio::io_service io_service;

    tcp::resolver resolver(io_service);
    tcp::resolver::query query(tcp::v4(), argv[1], argv[2]);
    tcp::resolver::iterator iterator = resolver.resolve(query);

    tcp::socket s(io_service);
    s.connect(*iterator);
    std::vector<int> num_of_pt(1);
    boost::asio::read(s,boost::asio::buffer(num_of_pt),boost::asio::transfer_all());
    std::cout <<"num_of_pt.size="<<num_of_pt[0]<<std::endl;
    std::vector<short> abc(num_of_pt[0]);
    int num=0;
    try{
        num = boost::asio::read(s,boost::asio::buffer(abc),boost::asio::transfer_all());
    }
    catch(boost::system::system_error const& e)
    {
    	std::cout <<"warning:"<<e.what()<<std::endl;
   		//std::cout<<abc.size()<<std::endl;
		}
   		std::cout<<abc.size()<<std::endl;
    pcl::PointCloud<pcl::PointXYZ> cloud;
    for(int j=0;j<num_of_pt[0];j+=3)
    {
        pcl::PointXYZ temp;
        double x=static_cast<double> (abc[j]);
        double y=static_cast<double> (abc[j+1]);
        double z=static_cast<double> (abc[j+2]);
        temp.x = x/1000;
        temp.y = y/1000;
        temp.z = z/1000;
        cloud.push_back(temp);
    }
    cout<<"cloud.size="<<cloud.size();
    pcl::PCDWriter writer;
    writer.write("receive.pcd",cloud);
    */

    pcl::PCDReader reader;
    /*
	  boost::asio::io_service io_service;

    tcp::resolver resolver(io_service);
    tcp::resolver::query query(tcp::v4(), argv[1], argv[2]);
    tcp::resolver::iterator iterator = resolver.resolve(query);

    tcp::socket s(io_service);
    s.connect(*iterator);
    */
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_s(new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_f(new pcl::PointCloud<pcl::PointXYZ>);
    reader.read<pcl::PointXYZ> ("3.pcd",*cloud_s);
    pcl::VoxelGrid<pcl::PointXYZ> sor;
    vector<int> dics;
    pcl::removeNaNFromPointCloud(*cloud_s,*cloud_s,dics);
    sor.setInputCloud(cloud_s);
    sor.setLeafSize(0.01f,0.01f,0.01f);
    sor.filter(*cloud_f);
    cout <<"read over,start send datas\n"<<endl;
    double t0 = ros::Time::now().toSec();
    Net_transfor n1(0);
    n1.send(*cloud_f);
    double t1 = ros::Time::now().toSec();
    cout <<"send spend time="<<(t1-t0)<<endl;
    n1.send(*cloud_f);
    n1.send(*cloud_f);
    n1.send(*cloud_f);
    
    

    sleep(2);

    while(ros::ok())
    {
        cout <<"circle\n";
        
        sleep(2);
        
    }
    n1.close_send();
    //s.shutdown();
    //s.close();
    /*
    int num = cloud_f->size();
    vector<short> points(num*3);
    const int conversion = 1000;
    for(int i=0;i<num;++i)
    {
        const pcl::PointXYZ& point = cloud_f->points[i];
        points[i*3+0] = static_cast<short>(point.x*conversion);
        points[i*3+1] = static_cast<short>(point.y*conversion);
        points[i*3+2] = static_cast<short>(point.z*conversion);
    }
    vector<int> num_of_pt(1);
    num_of_pt[0] = points.size();
    try{
        boost::asio::write(s,boost::asio::buffer(num_of_pt));
        boost::asio::write(s,boost::asio::buffer(points));
    }
    catch(boost::system::system_error const& e)
    {
        cout <<"warning:"<<e.what()<<endl;
    }
    cout <<"发送完成\n";
    */
}
